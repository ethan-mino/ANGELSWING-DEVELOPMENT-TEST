require 'rails_helper'

RSpec.describe Project, type: :model do 
	# 공통
		# authentication이 필요한지 확인
		# response가 명세와 동일한지 확인
	
		# Parameter validation
			# 존재하지 않는 type이 입력되었을 때, 에러를 발생시키는 지 확인
			# required parameter가 주어지지 않았을 때, 에러를 발생시키는 지 확인
			# permitted parameter 외에 다른 Parameter가 있을 때 proeject를 생성할 수 있는지 확인
	
	# GET /projects
		# project가 존재하지 않는 경우
		# 모든 프로젝트가 출력되는지 확인
		# 프로젝트를 생성한 유저가 올바른지 확인	
	
	# GET project/:id
		# 해당 project가 존재하지 않는 경우
		# 프로젝트를 생성한 유저가 올바른지 확인
	
	# GET /projects/my_projects
		# 프로젝트를 생성한 유저와 요청한 유저의 이름이 동일한지 확인
		# 프로젝트를 생성한 유저가 올바른지 확인
		# 다른 유저의 프로젝트가 포함되지 않는지 확인
	
	# POST /projects
		# 존재하지 않는 project type이 주어진 경우
		# 동일한 title로 project를 생성할 수 있는지 확인
		
	# PUT /projects/:id
		# 존재하지 않는 project type이 주어진 경우
		# 동일한 title로 project를 생성할 수 있는지 확인
		# 존재하지 않는 project인 경우
		# 본인이 생성한 프로젝트가 아닌 경우
	
	# DELETE /projects/:id
		# 존재하지 않는 project인 경우
		# 본인이 생성한 프로젝트가 아닌 경우
		# 프로젝트에 속하는 모든 콘텐츠가 삭제되는지 확인
end